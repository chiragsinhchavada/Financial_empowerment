/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `wp_postmeta` VALUES
(1,2,"_wp_page_template","default"),
(2,3,"_wp_page_template","default"),
(3,5,"_wp_trash_meta_status","publish"),
(4,5,"_wp_trash_meta_time","1550779258"),
(5,2,"_edit_lock","1550779291:1"),
(6,3,"_edit_lock","1550779301:1"),
(12,7,"_edit_lock","1550779385:1"),
(13,2,"_wp_trash_meta_status","publish"),
(14,2,"_wp_trash_meta_time","1550779587"),
(15,2,"_wp_desired_post_slug","sample-page"),
(16,9,"_edit_lock","1550780619:1"),
(17,9,"_wp_trash_meta_status","publish"),
(18,9,"_wp_trash_meta_time","1550780637"),
(19,10,"_edit_lock","1550780708:1"),
(20,10,"_wp_trash_meta_status","publish"),
(21,10,"_wp_trash_meta_time","1550780756");
