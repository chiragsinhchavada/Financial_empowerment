/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `wp_users` VALUES
(1,"chiragsinhdineshsinh.chavada@dcmail.ca","$P$BsCMZH22EHOYX52A/Edsb0Uc1uLqzq0","chiragsinhdineshsinh-chavadadcmail-ca","chiragsinhdineshsinh.chavada@dcmail.ca","","2019-02-21 19:56:38","",0,"chiragsinhdineshsinh.chavada@dcmail.ca");
